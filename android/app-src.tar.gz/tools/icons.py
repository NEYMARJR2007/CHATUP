import sys,os
from PIL import Image
src=Image.open(sys.argv[1]).convert('RGBA')
for d,s in [('mdpi',48),('hdpi',72),('xhdpi',96),('xxhdpi',144),('xxxhdpi',192)]:
    os.makedirs('app/src/main/res/mipmap-'+d,exist_ok=True)
    src.resize((s,s),Image.LANCZOS).save('app/src/main/res/mipmap-%s/ic_launcher.png'%d)
print('icons ok')
