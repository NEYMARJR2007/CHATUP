const fs=require('fs');const src=fs.readFileSync(process.argv[2],'utf8');
const grab=n=>{const i=src.indexOf('const '+n+'=[');let d=0,j=i+('const '+n+'=').length;for(;j<src.length;j++){if(src[j]==='[')d++;if(src[j]===']'){d--;if(!d){j++;break}}}return eval(src.slice(i+('const '+n+'=').length,j))};
const N=n=>440*Math.pow(2,(n-69)/12);
const MSG=grab('TONES_MSG'),RING=grab('TONES_RING');
const SR=44100;
function render(notes,secs){const out=new Float32Array(Math.ceil(SR*secs));
 for(const [p,st,du,wave,vol,mod] of notes){const f0=p>200?p:N(p);const v=Math.min(.9,(vol||.4)*1.6);let ph=0;
  const s0=Math.floor(st*SR),s1=Math.min(out.length,Math.floor((st+du+.05)*SR));
  for(let i=s0;i<s1;i++){const t=(i-s0)/SR;let f=f0;
   if(mod==='up')f=f0*Math.pow(1.6,Math.min(1,t/du));if(mod==='down')f=f0*Math.pow(.4,Math.min(1,t/du));if(mod==='vib')f=f0+f0*.06*Math.sin(2*Math.PI*38*t);
   ph+=2*Math.PI*f/SR;const x=ph/(2*Math.PI)%1;
   let w=wave==='square'?(x<.5?1:-1):wave==='sawtooth'?2*x-1:wave==='triangle'?1-4*Math.abs(x-.5):Math.sin(ph);
   let g=t<.012?v*t/.012:(t<du?v*Math.pow(.0001/v,(t-.012)/Math.max(.001,du-.012)):0);
   out[i]+=w*g}}
 let pk=0;for(const s of out)pk=Math.max(pk,Math.abs(s));const k=pk?Math.min(4,.95/pk):1;
 const b=Buffer.alloc(44+out.length*2);b.write('RIFF',0);b.writeUInt32LE(36+out.length*2,4);b.write('WAVE',8);b.write('fmt ',12);b.writeUInt32LE(16,16);b.writeUInt16LE(1,20);b.writeUInt16LE(1,22);b.writeUInt32LE(SR,24);b.writeUInt32LE(SR*2,28);b.writeUInt16LE(2,32);b.writeUInt16LE(16,34);b.write('data',36);b.writeUInt32LE(out.length*2,40);
 out.forEach((s,i)=>b.writeInt16LE(Math.max(-32768,Math.min(32767,Math.round(s*k*32767))),44+i*2));return b}
const dir='app/src/main/res/raw/';fs.mkdirSync(dir,{recursive:true});
for(const t of MSG){const end=Math.max(...t[2].map(n=>n[1]+n[2]))+.3;fs.writeFileSync(dir+'msg_'+t[0]+'.wav',render(t[2],end))}
for(const t of RING){const per=t[3]||2.4;fs.writeFileSync(dir+'ring_'+t[0]+'.wav',render(t[2],per))}
console.log(MSG.length,RING.length,fs.readdirSync(dir).length);
