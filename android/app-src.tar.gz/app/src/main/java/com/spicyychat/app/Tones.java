package com.spicyychat.app;

import android.app.NotificationChannel;
import android.app.NotificationChannelGroup;
import android.app.NotificationManager;
import android.content.ContentResolver;
import android.content.Context;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;

/** One notification channel per sound, so the sound picked in the app is the one Android plays. */
final class Tones {
    static NotificationManager nm(Context c) { return (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE); }

    static void ensureBaseChannels(Context c) {
        if (Build.VERSION.SDK_INT < 26) return;
        NotificationManager nm = nm(c);
        nm.createNotificationChannelGroup(new NotificationChannelGroup("messages", "הודעות"));
        nm.createNotificationChannelGroup(new NotificationChannelGroup("calls", "שיחות"));
        NotificationChannel ongoing = new NotificationChannel("ongoing", "שיחה פעילה", NotificationManager.IMPORTANCE_LOW);
        ongoing.setDescription("מוצג בזמן שיחה, כדי שהשיחה תמשיך גם כשיוצאים מהאפליקציה");
        nm.createNotificationChannel(ongoing);
    }

    static Uri raw(Context c, String name) {
        int id = c.getResources().getIdentifier(name, "raw", c.getPackageName());
        if (id == 0) return null;
        return Uri.parse(ContentResolver.SCHEME_ANDROID_RESOURCE + "://" + c.getPackageName() + "/raw/" + name);
    }

    /** kind: msg | group */
    static String messageChannel(Context c, String kind) {
        String tone = Prefs.tone(c, kind, "chatup");
        if ("custom".equals(tone)) tone = "chatup";
        String id = ("group".equals(kind) ? "grp_" : "msg_") + tone;
        if (Build.VERSION.SDK_INT < 26) return id;
        if (nm(c).getNotificationChannel(id) != null) return id;
        ensureBaseChannels(c);
        String label = ("group".equals(kind) ? "קבוצות" : "הודעות") + ("none".equals(tone) ? " (ללא צליל)" : " · " + tone);
        NotificationChannel ch = new NotificationChannel(id, label, NotificationManager.IMPORTANCE_HIGH);
        ch.setGroup("messages");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 120, 60, 120});
        ch.setLockscreenVisibility(android.app.Notification.VISIBILITY_PRIVATE);
        Uri u = "none".equals(tone) ? null : raw(c, "msg_" + tone);
        if ("none".equals(tone)) ch.setSound(null, null);
        else if (u != null) ch.setSound(u, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_COMMUNICATION_INSTANT).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        nm(c).createNotificationChannel(ch);
        return id;
    }

    static String callChannel(Context c) {
        String tone = Prefs.tone(c, "call", "classic");
        if ("custom".equals(tone)) tone = "classic";
        String id = "call_" + tone;
        if (Build.VERSION.SDK_INT < 26) return id;
        if (nm(c).getNotificationChannel(id) != null) return id;
        ensureBaseChannels(c);
        NotificationChannel ch = new NotificationChannel(id, "שיחות נכנסות" + ("none".equals(tone) ? " (ללא צליל)" : " · " + tone), NotificationManager.IMPORTANCE_HIGH);
        ch.setGroup("calls");
        ch.enableVibration(true);
        ch.setVibrationPattern(new long[]{0, 600, 300, 600, 300, 600, 300, 600});
        ch.setLockscreenVisibility(android.app.Notification.VISIBILITY_PUBLIC);
        ch.setBypassDnd(false);
        Uri u = "none".equals(tone) ? null : raw(c, "ring_" + tone);
        if ("none".equals(tone)) ch.setSound(null, null);
        else if (u != null) ch.setSound(u, new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());
        nm(c).createNotificationChannel(ch);
        return id;
    }
}
