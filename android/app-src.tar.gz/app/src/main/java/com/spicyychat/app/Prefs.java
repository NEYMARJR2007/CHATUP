package com.spicyychat.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONObject;

final class Prefs {
    static SharedPreferences p(Context c) { return c.getSharedPreferences("spicyy", Context.MODE_PRIVATE); }
    static String token(Context c) { return p(c).getString("token", null); }
    static void setToken(Context c, String t) { p(c).edit().putString("token", t).apply(); }
    static void setTones(Context c, String json) { p(c).edit().putString("tones", json).apply(); }
    static String tone(Context c, String kind, String def) {
        try {
            JSONObject o = new JSONObject(p(c).getString("tones", "{}"));
            String v = o.optString(kind, def);
            return v == null || v.isEmpty() ? def : v;
        } catch (Exception e) { return def; }
    }
}
