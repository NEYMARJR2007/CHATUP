package com.spicyychat.app;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.core.content.ContextCompat;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialCancellationException;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption;

import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** The SpicyyChat app: a full-screen WebView that runs the web app, plus native notifications and calls. */
public class MainActivity extends Activity {
    static final String HOME = "https://neymarjr2007.github.io/CHATUP/";
    static MainActivity instance;
    static boolean resumed;
    WebView web;
    ValueCallback<Uri[]> fileCb;
    PermissionRequest pendingPerm;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        instance = this;
        Tones.ensureBaseChannels(this);
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setUserAgentString(s.getUserAgentString() + " SpicyyChatApp/1");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);
        web.addJavascriptInterface(new Bridge(this), "SpicyyAndroid");
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                Uri u = req.getUrl();
                String h = u.getHost() == null ? "" : u.getHost();
                if (h.equals("neymarjr2007.github.io") || h.endsWith("firebaseapp.com") || h.endsWith("google.com")
                        || h.endsWith("gstatic.com") || h.endsWith("googleapis.com") || h.endsWith("recaptcha.net")) return false;
                try { startActivity(new Intent(Intent.ACTION_VIEW, u)); } catch (Exception e) { /* no app for this link */ }
                return true;
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onPermissionRequest(final PermissionRequest r) {
                runOnUiThread(() -> {
                    List<String> need = new ArrayList<>();
                    for (String res : r.getResources()) {
                        if (PermissionRequest.RESOURCE_VIDEO_CAPTURE.equals(res) && !has(Manifest.permission.CAMERA)) need.add(Manifest.permission.CAMERA);
                        if (PermissionRequest.RESOURCE_AUDIO_CAPTURE.equals(res) && !has(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
                    }
                    if (need.isEmpty()) r.grant(r.getResources());
                    else { pendingPerm = r; requestPermissions(need.toArray(new String[0]), 11); }
                });
            }

            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams p) {
                if (fileCb != null) fileCb.onReceiveValue(null);
                fileCb = cb;
                try { startActivityForResult(p.createIntent(), 12); }
                catch (Exception e) { fileCb = null; return false; }
                return true;
            }
        });
        if (Build.VERSION.SDK_INT >= 33 && !has(Manifest.permission.POST_NOTIFICATIONS)) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 13);
        }
        PushService.refreshToken(this);
        handleIntent(getIntent(), true);
    }

    boolean has(String p) { return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED; }

    void handleIntent(Intent i, boolean first) {
        String hash = i != null ? i.getStringExtra("hash") : null;
        Uri data = i != null ? i.getData() : null;
        if (i != null && i.getBooleanExtra("call", false)) showOnLock(true);
        if (first) {
            String url = HOME;
            if (data != null && data.toString().startsWith(HOME)) url = data.toString();
            else if (hash != null) url = HOME + "#" + hash;
            web.loadUrl(url);
        } else if (hash != null) {
            web.evaluateJavascript("window.spicyyIntent&&window.spicyyIntent(" + JSONObject.quote(hash) + ")", null);
        } else if (data != null && data.toString().startsWith(HOME)) {
            web.loadUrl(data.toString());
        }
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        setIntent(i);
        handleIntent(i, false);
    }

    /** show this screen over the lock screen and turn the screen on (only while a call is ringing or active) */
    void showOnLock(boolean on) {
        if (Build.VERSION.SDK_INT >= 27) {
            setShowWhenLocked(on);
            setTurnScreenOn(on);
        } else {
            int f = WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON;
            if (on) getWindow().addFlags(f); else getWindow().clearFlags(f);
        }
        if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    static final String WEB_CLIENT_ID = "60685364216-8npp2ipa56vd8l1ui9dd517us18d6q3e.apps.googleusercontent.com";
    static final String GOOGLE_ID_TYPE = "com.google.android.libraries.identity.googleid.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL";
    static final String GOOGLE_ID_TOKEN = "com.google.android.libraries.identity.googleid.BUNDLE_KEY_ID_TOKEN";

    void googleResult(String token, String err) {
        js("window.spicyyGoogle&&window.spicyyGoogle(" + (token == null ? "null" : JSONObject.quote(token)) + "," + (err == null ? "null" : JSONObject.quote(err)) + ")");
    }

    void googleSignIn() {
        try {
            GetSignInWithGoogleOption opt = new GetSignInWithGoogleOption.Builder(WEB_CLIENT_ID).build();
            GetCredentialRequest req = new GetCredentialRequest.Builder().addCredentialOption(opt).build();
            CredentialManager.create(this).getCredentialAsync(this, req, new CancellationSignal(), ContextCompat.getMainExecutor(this),
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override
                    public void onResult(GetCredentialResponse r) {
                        Credential c = r.getCredential();
                        String tok = null;
                        if (c instanceof CustomCredential && GOOGLE_ID_TYPE.equals(c.getType())) tok = c.getData().getString(GOOGLE_ID_TOKEN);
                        if (tok != null) googleResult(tok, null); else googleResult(null, "type " + c.getType());
                    }

                    @Override
                    public void onError(GetCredentialException e) {
                        googleResult(null, e instanceof GetCredentialCancellationException ? "cancel" : e.getClass().getSimpleName() + ": " + e.getMessage());
                    }
                });
        } catch (Exception e) {
            googleResult(null, "start: " + e);
        }
    }

    void js(String code) { runOnUiThread(() -> { if (web != null) web.evaluateJavascript(code, null); }); }

    void pushTokenToWeb() {
        String t = Prefs.token(this);
        if (t != null) js("window.spicyyOnToken&&window.spicyyOnToken(" + JSONObject.quote(t) + ")");
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        if (code == 11 && pendingPerm != null) {
            boolean ok = true;
            for (int r : res) if (r != PackageManager.PERMISSION_GRANTED) ok = false;
            if (ok) pendingPerm.grant(pendingPerm.getResources()); else pendingPerm.deny();
            pendingPerm = null;
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == 12 && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else moveTaskToBack(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (web != null) web.onResume();
        js("window.spicyyResume&&window.spicyyResume()");
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        /* the WebView is not paused, so calls keep going in the background */
    }

    @Override
    protected void onDestroy() {
        if (instance == this) instance = null;
        if (web != null) { web.destroy(); web = null; }
        super.onDestroy();
    }
}
