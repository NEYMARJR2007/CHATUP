package com.spicyychat.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.os.Build;
import android.os.IBinder;

import androidx.core.app.NotificationCompat;

/** Keeps a call alive while the user is in another app (shows "call in progress"). */
public class CallService extends Service {
    static void start(Context c, String name) {
        try {
            Intent i = new Intent(c, CallService.class).putExtra("name", name);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception e) { /* not allowed right now */ }
    }

    static void stop(Context c) {
        try { c.stopService(new Intent(c, CallService.class)); } catch (Exception e) { /* ignore */ }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        String name = intent != null ? intent.getStringExtra("name") : null;
        Intent open = new Intent(this, MainActivity.class).setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 7, open, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification n = new NotificationCompat.Builder(this, "ongoing")
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(0xFFE8590C)
                .setContentTitle("שיחה פעילה")
                .setContentText(name == null ? "SpicyyChat" : name)
                .setOngoing(true)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setContentIntent(pi)
                .build();
        try {
            if (Build.VERSION.SDK_INT >= 30) startForeground(42, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE);
            else startForeground(42, n);
        } catch (Exception e) { stopSelf(); }
        return START_NOT_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }
}
