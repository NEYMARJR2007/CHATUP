package com.spicyychat.app;

import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.media.AudioDeviceInfo;
import android.media.AudioManager;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;
import android.webkit.JavascriptInterface;

import java.util.List;

/** Functions the web app can call: window.SpicyyAndroid.xxx() */
public class Bridge {
    final MainActivity a;
    Bridge(MainActivity a) { this.a = a; }

    @JavascriptInterface public String version() { return "1"; }
    @JavascriptInterface public String token() { String t = Prefs.token(a); return t == null ? "" : t; }

    /** {"msg":"goal","group":"chatup","call":"classic"} */
    @JavascriptInterface public void setTones(String json) { Prefs.setTones(a, json); }

    @JavascriptInterface public void callStarted(String name) {
        Notifs.cancelAllCalls(a);
        CallService.start(a, name);
        a.runOnUiThread(() -> a.showOnLock(true));
    }

    @JavascriptInterface public void callEnded() {
        CallService.stop(a);
        setSpeakerInternal(false, true);
        a.runOnUiThread(() -> a.showOnLock(false));
    }

    @JavascriptInterface public void cancelCall(String id) { Notifs.cancelCall(a, id); }

    @JavascriptInterface public void setSpeaker(boolean on) { setSpeakerInternal(on, false); }

    @SuppressWarnings("deprecation")
    void setSpeakerInternal(boolean on, boolean reset) {
        AudioManager am = (AudioManager) a.getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return;
        try {
            if (reset) {
                if (Build.VERSION.SDK_INT >= 31) am.clearCommunicationDevice();
                am.setSpeakerphoneOn(false);
                am.setMode(AudioManager.MODE_NORMAL);
                return;
            }
            am.setMode(AudioManager.MODE_IN_COMMUNICATION);
            if (Build.VERSION.SDK_INT >= 31) {
                List<AudioDeviceInfo> devs = am.getAvailableCommunicationDevices();
                int want = on ? AudioDeviceInfo.TYPE_BUILTIN_SPEAKER : AudioDeviceInfo.TYPE_BUILTIN_EARPIECE;
                boolean done = false;
                if (!on) { /* a headset or bluetooth wins over the earpiece */
                    for (AudioDeviceInfo d : devs) {
                        int t = d.getType();
                        if (t == AudioDeviceInfo.TYPE_BLUETOOTH_SCO || t == AudioDeviceInfo.TYPE_WIRED_HEADSET || t == AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == AudioDeviceInfo.TYPE_USB_HEADSET) {
                            done = am.setCommunicationDevice(d); break;
                        }
                    }
                }
                if (!done) for (AudioDeviceInfo d : devs) if (d.getType() == want) { am.setCommunicationDevice(d); break; }
            } else {
                am.setSpeakerphoneOn(on);
            }
        } catch (Exception e) { /* ignore */ }
    }

    @JavascriptInterface public boolean canFullScreen() {
        if (Build.VERSION.SDK_INT >= 34) {
            NotificationManager nm = (NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.canUseFullScreenIntent();
        }
        return true;
    }

    @JavascriptInterface public boolean notificationsOn() {
        NotificationManager nm = (NotificationManager) a.getSystemService(Context.NOTIFICATION_SERVICE);
        return nm != null && nm.areNotificationsEnabled();
    }

    @JavascriptInterface public void openNotifSettings() {
        Intent i = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, a.getPackageName());
        start(i);
    }

    @JavascriptInterface public void openFullScreenSettings() {
        if (Build.VERSION.SDK_INT >= 34) start(new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:" + a.getPackageName())));
        else openNotifSettings();
    }

    @JavascriptInterface public void openBatterySettings() {
        start(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + a.getPackageName())));
    }

    void start(Intent i) {
        try { a.startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Exception e) { /* settings page missing */ }
    }
}
