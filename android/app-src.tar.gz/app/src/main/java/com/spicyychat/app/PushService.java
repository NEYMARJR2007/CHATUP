package com.spicyychat.app;

import android.content.Context;

import com.google.firebase.FirebaseApp;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.util.Map;

/** Receives messages from the SpicyyChat server (through Firebase Cloud Messaging), even when the app is closed. */
public class PushService extends FirebaseMessagingService {

    static void refreshToken(Context c) {
        try {
            if (FirebaseApp.getApps(c).isEmpty()) return; /* google-services.json not added yet */
            FirebaseMessaging.getInstance().getToken().addOnCompleteListener(t -> {
                if (t.isSuccessful() && t.getResult() != null) {
                    Prefs.setToken(c, t.getResult());
                    if (MainActivity.instance != null) MainActivity.instance.pushTokenToWeb();
                }
            });
        } catch (Exception e) { /* Firebase not set up */ }
    }

    @Override
    public void onNewToken(String token) {
        Prefs.setToken(this, token);
        if (MainActivity.instance != null) MainActivity.instance.pushTokenToWeb();
    }

    @Override
    public void onMessageReceived(RemoteMessage m) {
        Map<String, String> d = m.getData();
        String t = d.get("t");
        if (t == null) return;
        boolean visible = MainActivity.instance != null && MainActivity.resumed;
        switch (t) {
            case "msg":
                if (visible) return; /* the app shows its own banner */
                Notifs.message(this, d.get("cid"), val(d, "title", "SpicyyChat"), val(d, "body", "הודעה חדשה"), "1".equals(d.get("g")));
                break;
            case "call":
                if (visible) return; /* the app shows the call screen itself */
                Notifs.incomingCall(this, val(d, "id", "x"), val(d, "title", "SpicyyChat"), "1".equals(d.get("video")));
                break;
            case "callend":
                Notifs.cancelCall(this, d.get("id"));
                if (MainActivity.instance != null) MainActivity.instance.js("window.spicyyCallEnd&&window.spicyyCallEnd(" + org.json.JSONObject.quote(val(d, "id", "")) + ")");
                break;
            default:
                break;
        }
    }

    static String val(Map<String, String> d, String k, String def) {
        String v = d.get(k);
        return v == null || v.isEmpty() ? def : v;
    }
}
