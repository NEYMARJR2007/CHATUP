package com.spicyychat.app;

import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.app.Person;

final class Notifs {
    static PendingIntent open(Context c, String hash, boolean call, int req) {
        Intent i = new Intent(c, MainActivity.class)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                .putExtra("hash", hash).putExtra("call", call);
        return PendingIntent.getActivity(c, req, i, PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    static boolean canPost(Context c) {
        return NotificationManagerCompat.from(c).areNotificationsEnabled();
    }

    @SuppressWarnings("MissingPermission")
    static void message(Context c, String cid, String title, String body, boolean group) {
        if (!canPost(c)) return;
        String ch = Tones.messageChannel(c, group ? "group" : "msg");
        int id = (cid == null ? "x" : cid).hashCode();
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, ch)
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(0xFFE8590C)
                .setContentTitle(title)
                .setContentText(body)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(body))
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true)
                .setContentIntent(open(c, cid == null ? null : "open-" + cid, false, id));
        NotificationManagerCompat.from(c).notify("msg", id, b.build());
    }

    @SuppressWarnings("MissingPermission")
    static void incomingCall(Context c, String callId, String name, boolean video) {
        if (!canPost(c)) return;
        int id = callId.hashCode();
        PendingIntent full = open(c, "call-" + callId, true, id);
        PendingIntent answer = open(c, "answer-" + callId, true, id + 1);
        PendingIntent decline = open(c, "decline-" + callId, false, id + 2);
        Person caller = new Person.Builder().setName(name).setImportant(true).build();
        NotificationCompat.Builder b = new NotificationCompat.Builder(c, Tones.callChannel(c))
                .setSmallIcon(R.drawable.ic_stat)
                .setColor(0xFFE8590C)
                .setContentTitle(name)
                .setContentText(video ? "שיחת וידאו נכנסת" : "שיחה קולית נכנסת")
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
                .setOngoing(true)
                .setAutoCancel(true)
                .setTimeoutAfter(45000)
                .setContentIntent(full)
                .setFullScreenIntent(full, true)
                .setStyle(NotificationCompat.CallStyle.forIncomingCall(caller, decline, answer).setIsVideo(video));
        Notification n = b.build();
        n.flags |= Notification.FLAG_INSISTENT;
        NotificationManagerCompat.from(c).notify("call", id, n);
    }

    static void cancelCall(Context c, String callId) {
        if (callId == null) return;
        NotificationManagerCompat.from(c).cancel("call", callId.hashCode());
    }

    static void cancelAllCalls(Context c) {
        if (Build.VERSION.SDK_INT >= 23) {
            android.app.NotificationManager nm = (android.app.NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null) return;
            for (android.service.notification.StatusBarNotification s : nm.getActiveNotifications()) {
                if ("call".equals(s.getTag())) nm.cancel("call", s.getId());
            }
        }
    }
}
